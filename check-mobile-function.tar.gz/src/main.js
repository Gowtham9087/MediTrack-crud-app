const { Client, Databases, Query } = require("node-appwrite");

module.exports = async function ({ req, res, log, error }) {
  try {
    const data = JSON.parse(req.body || "{}");
    const contact = data.contact;

    if (!contact) {
      return res.json({ success: false, message: "Mobile required ❌" });
    }

    const client = new Client()
      .setEndpoint("https://cloud.appwrite.io/v1")
      .setProject("69f048ec0011acce6a02")
      .setKey(process.env.API_KEY);

    const databases = new Databases(client);

    const result = await databases.listDocuments(
      process.env.DATABASE_ID,
      process.env.PATIENT_TABLE_ID,
      [Query.equal("contact", contact)]
    );

    log("Documents found: " + result.documents.length);

    if (result.documents.length > 0) {
      return res.json({ success: false, message: "Mobile already exists ❌" });
    }

    return res.json({ success: true, message: "Mobile available ✔️" });
  } catch (err) {
    error(err.message);
    return res.json({ success: false, message: err.message });
  }
};